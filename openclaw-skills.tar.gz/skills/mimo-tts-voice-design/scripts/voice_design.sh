#!/usr/bin/env bash
# voice_design.sh — Generate a brand-new voice from a natural-language
#                   description with MiMo-V2.5-TTS-VoiceDesign, then speak the
#                   given text in that voice and save it as a WAV file.
#
# Usage:
#   voice_design.sh <voice_description> <text> <output_path>
#
# Arguments:
#   voice_description  Natural-language description of the voice to create, e.g.
#                      "一位中年男性，说标准普通话，嗓音低沉有磁性，像纪录片旁白" or
#                      "Heavy Russian accent, gruff middle-aged male, blunt".
#                      No reference audio is needed — the voice is generated
#                      from this description alone.
#   text               Text to speak in the generated voice (required).
#                      Apply TTS normalization before passing.
#   output_path        Destination WAV file path (required). Parent dir must exist.
#
# Environment variables:
#   MIMO_API_KEY            (required) MiMo platform API key. If unset, falls back
#                           to models.providers.xiaomi.apiKey in ~/.openclaw/openclaw.json
#   MIMO_API_BASE_URL       (optional) Override base URL (default https://api.xiaomimimo.com/v1)
#   MIMO_VOICEDESIGN_MODEL  (optional) Override model name (default mimo-v2.5-tts-voicedesign)
#
# Exit codes:
#   0  Success — WAV written to output_path
#   1  Missing required argument or API key not found
#   2  API request failed or returned an error
#   3  Output file could not be written

set -euo pipefail

# ── Arguments ──────────────────────────────────────────────────────────────
VOICE_DESCRIPTION="${1:-}"
TEXT="${2:-}"
OUTPUT_PATH="${3:-}"

usage() {
  echo "Usage: $(basename "$0") <voice_description> <text> <output_path>" >&2
}

# ── Validation ─────────────────────────────────────────────────────────────
if [[ -z "$VOICE_DESCRIPTION" ]]; then
  echo "Error: <voice_description> is required" >&2; usage; exit 1
fi
if [[ -z "$TEXT" ]]; then
  echo "Error: <text> is required" >&2; usage; exit 1
fi
if [[ -z "$OUTPUT_PATH" ]]; then
  echo "Error: <output_path> is required" >&2; usage; exit 1
fi

# Resolve API key: env var → openclaw.json → error
if [[ -z "${MIMO_API_KEY:-}" ]]; then
  _OPENCLAW="$HOME/.openclaw/openclaw.json"
  if [[ -f "$_OPENCLAW" ]]; then
    MIMO_API_KEY=$(python3 -c "
import json, sys
try:
    d = json.load(open('$_OPENCLAW'))
    print(d['models']['providers']['xiaomi']['apiKey'])
except (KeyError, TypeError):
    sys.exit(1)
" 2>/dev/null) || true
  fi
fi
if [[ -z "${MIMO_API_KEY:-}" ]]; then
  echo "Error: MiMo API key not found." >&2
  echo "  Set MIMO_API_KEY env var, or add models.providers.xiaomi.apiKey to ~/.openclaw/openclaw.json" >&2
  exit 1
fi

TTS_ENDPOINT="${MIMO_API_BASE_URL:-https://api.xiaomimimo.com/v1}"
TTS_ENDPOINT="${TTS_ENDPOINT%/}/chat/completions"
MODEL="${MIMO_VOICEDESIGN_MODEL:-mimo-v2.5-tts-voicedesign}"

WORK_DIR=$(mktemp -d)
trap 'rm -rf "$WORK_DIR"' EXIT

# ── Build request payload (official VoiceDesign format) ─────────────────────
# The voice description goes into the user message; the text to synthesize goes
# into the assistant message. optimize_text_preview lets the model refine the
# spoken text for a more natural preview.
PAYLOAD=$(jq -n \
  --arg model "$MODEL" \
  --arg desc "$VOICE_DESCRIPTION" \
  --arg content "$TEXT" \
  '{model: $model,
    messages: [
      {role: "user", content: $desc},
      {role: "assistant", content: $content}
    ],
    audio: {format: "wav", optimize_text_preview: true}}')

# ── Call the API (with retry on transient errors) ───────────────────────────
# The TTS backend occasionally returns transient failures (5xx, or 4xx with a
# generic "Request failed" / "returned empty text" message). Those succeed on
# retry. Hard errors (bad params, invalid key) are NOT retried — retrying is
# pointless and only wastes time.
MAX_ATTEMPTS=3
HTTP_CODE=""
for attempt in $(seq 1 "$MAX_ATTEMPTS"); do
  HTTP_CODE=$(curl -s -w "%{http_code}" \
    -o "$WORK_DIR/resp.json" \
    --max-time 300 \
    -H "Content-Type: application/json" \
    -H "api-key: $MIMO_API_KEY" \
    -d "$PAYLOAD" \
    "$TTS_ENDPOINT") || HTTP_CODE="000"   # curl non-zero (network) → treat as retryable

  [[ "$HTTP_CODE" == "200" ]] && break

  # Decide whether this failure is worth retrying.
  RETRYABLE=0
  if [[ "$HTTP_CODE" =~ ^5 ]]; then
    RETRYABLE=1                       # any 5xx
  elif [[ "$HTTP_CODE" == "429" ]]; then
    RETRYABLE=1                       # rate limited
  elif [[ "$HTTP_CODE" =~ ^4 ]]; then
    # 4xx: retry only transient-looking messages, not real param errors.
    if grep -qiE 'request failed|returned empty text|timeout|try again' "$WORK_DIR/resp.json"; then
      RETRYABLE=1
    fi
  elif [[ -z "$HTTP_CODE" || "$HTTP_CODE" == "000" ]]; then
    RETRYABLE=1                       # network/curl failure
  fi

  if [[ "$RETRYABLE" -eq 1 && "$attempt" -lt "$MAX_ATTEMPTS" ]]; then
    delay=$((2 ** (attempt - 1)))     # 1s, 2s, 4s ...
    echo "Warning: API returned HTTP ${HTTP_CODE:-000} (attempt ${attempt}/${MAX_ATTEMPTS}), retrying in ${delay}s..." >&2
    sleep "$delay"
    continue
  fi
  break                               # non-retryable, or attempts exhausted
done

if [[ "$HTTP_CODE" != "200" ]]; then
  echo "Error: API returned HTTP $HTTP_CODE after ${attempt} attempt(s)" >&2
  cat "$WORK_DIR/resp.json" >&2
  exit 2
fi

# ── Decode audio data ───────────────────────────────────────────────────────
DECODE_SCRIPT="$WORK_DIR/decode.py"
cat > "$DECODE_SCRIPT" << 'PYEOF'
import json, base64, struct, io, sys

resp_path, out_path = sys.argv[1], sys.argv[2]

with open(resp_path) as f:
    data = json.load(f)

# Surface API-level errors
if data.get('error'):
    print(f"Error: API error: {data['error']}", file=sys.stderr)
    sys.exit(2)

try:
    audio = data['choices'][0]['message']['audio']
    raw = base64.b64decode(audio['data'])
except (KeyError, IndexError, TypeError) as e:
    print(f"Error: unexpected response shape — {e}", file=sys.stderr)
    print(json.dumps(data, ensure_ascii=False)[:400], file=sys.stderr)
    sys.exit(2)

# Handle both WAV (RIFF header present) and raw PCM
if raw[:4] == b'RIFF':
    wav_bytes = raw
else:
    # Wrap raw PCM: 24kHz, 16-bit, mono
    sr, bps, ch = 24000, 16, 1
    br = sr * ch * bps // 8
    buf = io.BytesIO()
    buf.write(b'RIFF')
    buf.write(struct.pack('<I', 36 + len(raw)))
    buf.write(b'WAVEfmt ')
    buf.write(struct.pack('<IHHIIHH', 16, 1, ch, sr, br, ch * bps // 8, bps))
    buf.write(b'data')
    buf.write(struct.pack('<I', len(raw)))
    buf.write(raw)
    wav_bytes = buf.getvalue()

with open(out_path, 'wb') as f:
    f.write(wav_bytes)

print(f"OK: {len(wav_bytes)} bytes written to {out_path}")
PYEOF

python3 "$DECODE_SCRIPT" "$WORK_DIR/resp.json" "$OUTPUT_PATH"

# ── Verify output ───────────────────────────────────────────────────────────
if [[ ! -s "$OUTPUT_PATH" ]]; then
  echo "Error: output file is empty or was not created: $OUTPUT_PATH" >&2
  exit 3
fi
