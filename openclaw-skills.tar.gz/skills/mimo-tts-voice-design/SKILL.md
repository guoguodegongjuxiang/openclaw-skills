---
name: mimo-tts-voice-design
description: "使用 MiMo-V2.5-TTS-VoiceDesign 用一句话描述凭空生成全新音色并合成语音，无需参考音频，保存为 WAV。当用户描述想要的声音（口音/年龄/性别/气质/录音质感）并要求按此朗读时使用。"
homepage: https://mimo.xiaomi.com/mimo-v2-5-tts
metadata: { "openclaw": { "emoji": "🎨", "requires": { "bins": ["jq", "curl", "python3"] }, "primaryEnv": "MIMO_API_KEY" } }
---

# MiMo 音色设计 → WAV 文件

调用 MiMo-V2.5-TTS-VoiceDesign 模型，仅凭一句自然语言描述就**凭空生成全新音色**，
再用该音色把指定文本合成为标准 WAV 文件（24 kHz，16-bit PCM，单声道）。
**无需任何参考音频** —— 描述声音就像写一段文字一样直观。

---

## 何时使用

| 场景 | 用本 skill？ |
|---|---|
| 用户描述想要的声音（如「低沉磁性的纪录片旁白」）并要求朗读 | ✅ 是 |
| 「生成一个 XX 口音 / XX 年龄 / XX 气质的声音读…」 | ✅ 是 |
| 「ASMR 双耳女声」「俄罗斯口音中年男性」这类音色定义 | ✅ 是 |
| 想要某种声音但**手头没有参考录音** | ✅ 是（这正是本 skill 的核心场景） |
| 已有一段参考录音，想**复刻**那个人的音色 | ❌ 改用 `mimo-tts-voice-clone` |
| 只想用默认/预设音色合成普通语音 | ❌ 改用 `mimo-tts-wav` |
| 只是想分析/转录一段音频内容 | ❌ 改用 `mimo-omni` |

> 与 `mimo-tts-voice-clone` 的区别：voice-clone **从参考音频复刻**已有音色；
> 本 skill **从文字描述生成**一个全新音色，不需要任何参考音频。

---

## 前置条件

| 要求 | 说明 |
|---|---|
| `jq` | 构造 JSON 请求体。安装：`brew install jq` / `apt install jq` |
| `python3` | 仅用标准库（json、base64、struct）解码音频 |
| `curl` | 发送请求，通常已预装 |
| API Key | 设置 `MIMO_API_KEY`，或在 `~/.openclaw/openclaw.json` 配置 `models.providers.xiaomi.apiKey`（脚本自动读取） |

---

## 用法

```bash
bash {baseDir}/scripts/voice_design.sh <voice_description> <text> <output_path>
```

### 参数

| # | 名称 | 必填 | 说明 |
|---|---|---|---|
| 1 | `voice_description` | ✅ | 用自然语言描述想要的音色。可从年龄、性别、口音、气质、语速、录音质感等任意维度自由描述。中英文均可。 |
| 2 | `text` | ✅ | 要用该音色朗读的文本。传入前先做 TTS 文本规范化（见下文）。 |
| 3 | `output_path` | ✅ | 输出 WAV 文件路径，父目录需已存在。未指定时默认 `output.wav`。 |

### 环境变量

| 变量 | 默认值 | 说明 |
|---|---|---|
| `MIMO_API_KEY` | — | MiMo 平台 API Key（也可走 openclaw.json 自动解析） |
| `MIMO_API_BASE_URL` | `https://api.xiaomimimo.com/v1` | 覆盖 API 基础地址（会自动追加 `/chat/completions`） |
| `MIMO_VOICEDESIGN_MODEL` | `mimo-v2.5-tts-voicedesign` | 覆盖模型名 |

---

## 步骤

1. **写音色描述** —— 把用户想要的声音翻译成一句自然语言描述（见下方维度指南）。
   描述越具体，生成的音色越贴合预期；模型也能理解复杂、模糊甚至矛盾的描述。

2. **规范化文本** —— 对要朗读的 `text` 做 TTS 规范化（见下文），
   把数字、符号、markdown 转成自然口语。

3. **运行脚本**：
   ```bash
   bash {baseDir}/scripts/voice_design.sh "音色描述" "要朗读的内容" output.wav
   ```

4. **检查输出** —— 成功时脚本退出码为 `0`，并打印
   `OK: <N> bytes written to <path>`；出错时错误信息写到 stderr，退出码非零。

---

## 示例

```bash
# 纪录片旁白（中文描述）
bash {baseDir}/scripts/voice_design.sh \
  "一位中年男性，说标准普通话，嗓音低沉有磁性，带轻微沙哑质感，像纪录片旁白解说员，沉稳而有感染力" \
  "当最后一缕阳光消失在地平线之下，这片沉睡了亿万年的大地开始显露它真正的面貌。" \
  narrator.wav

# 年迈老先生（北方口音、语速缓慢）
bash {baseDir}/scripts/voice_design.sh \
  "一位年迈的老先生，说带北方口音的普通话，语速缓慢沉稳，嗓音略带沙哑和沧桑感，像饱经风霜的老爷爷讲故事" \
  "我这辈子啊，走南闯北六十多年，见过最热闹的集市，也见过最安静的戈壁。" \
  elder.wav

# 俄罗斯口音中年男性（英文描述）
bash {baseDir}/scripts/voice_design.sh \
  "Heavy Russian accent, gruff middle-aged male, blunt and matter-of-fact." \
  "You want my opinion? Fine. This plan will not work." \
  russian.wav

# ASMR 双耳女声（描述录音质感与氛围）
bash {baseDir}/scripts/voice_design.sh \
  "Young female, extreme close-up binaural ear-to-ear ASMR feel, audible breathing and soft lip sounds, speaks very slowly" \
  "[Whispering in your ear] Shhh... just relax, come a little closer." \
  asmr.wav

# 接 ffmpeg 转成 MP3
bash {baseDir}/scripts/voice_design.sh "年轻男声，清亮干净" "你好" /tmp/tmp.wav && \
  ffmpeg -i /tmp/tmp.wav out.mp3
```

---

## 音色描述维度指南

`voice_description` 接受**任意自然语言描述**，模型自由解读。可从以下维度自由组合，
也可只描述其中几项。不需要专业声学知识。

| 维度 | 示例 |
|---|---|
| 年龄 | `年轻` / `中年` / `年迈的老先生` / `小孩` |
| 性别 | `男声` / `女声` |
| 口音 | `标准普通话` / `北方口音` / `四川口音` / `Heavy Russian accent` / `British accent` |
| 音色质感 | `低沉有磁性` / `清亮干净` / `略带沙哑` / `温柔轻盈` |
| 语速气质 | `语速缓慢沉稳` / `干脆利落` / `慵懒` / `沉稳而有感染力` |
| 录音质感 | `纪录片旁白` / `播客质感` / `ASMR 双耳近距离` / `电台主播` |
| 角色原型 | `像饱经风霜的老爷爷讲故事` / `冥想助眠引导` / `赛后评论员` |

> 描述可以很具体也可以很模糊，模型对复杂、矛盾的描述也有良好理解能力。
> 既能还原从未听过的独特音色，也能复刻带鲜明特征的经典人物原型。

---

## TTS 文本规范化

把要朗读的文本传给脚本前先预处理，将不发音的符号替换为自然口语
（中文为主，英文文本按英文处理）。

### 数字
| 输入 | 朗读 |
|---|---|
| `3` | 三 |
| `3.14` | 三点一四 |
| `1/3` | 三分之一 |
| `14:30` | 下午两点半 |
| `95%` | 百分之九十五 |
| `2024`（年份） | 二零二四年 |

### 常见符号
| 符号 | 朗读 |
|---|---|
| `+` | 加 |
| `-` | 减 |
| `×` / `*` | 乘以 |
| `÷` / `/` | 除以 |
| `=` | 等于 |
| `>` / `<` | 大于 / 小于 |
| `%` | 百分之… |
| `~` | 大约 |
| `...` / `…` | 等等 |

### 格式残留
- 去掉 markdown（`**加粗**`、`# 标题`、`` `代码` ``、`- 列表`）
- 编号列表转成口语：「有三点，第一……第二……第三……」
- 表格转成描述关键数值的句子

---

## 多语言支持

- 支持中英文及多种口音的音色设计。
- 中文描述可生成普通话、方言音色；英文描述可生成俄罗斯口音、ASMR、播客等风格。
- `voice_description` 和 `text` 可以是不同语言（如英文描述 + 中文文本），
  但通常让描述里的口音/语言与要朗读的 `text` 语言一致，效果最自然。
- 文本规范化按 `text` 的语言处理。

---

## 请求格式说明

脚本采用官方文档的 VoiceDesign 格式：音色描述放进 `user` 消息，要朗读的文本放进
`assistant` 消息，`audio.format` 请求 WAV 输出，`optimize_text_preview` 让模型
优化朗读文本以获得更自然的预览。

```json
{
  "model": "mimo-v2.5-tts-voicedesign",
  "messages": [
    {"role": "user", "content": "音色描述，如：年轻男声，清亮干净"},
    {"role": "assistant", "content": "要朗读的文本"}
  ],
  "audio": {"format": "wav", "optimize_text_preview": true}
}
```

---

## 输出格式

脚本始终写出标准 RIFF WAV 文件：

| 属性 | 值 |
|---|---|
| 格式 | WAV (RIFF) |
| 采样率 | 24 000 Hz |
| 位深 | 16-bit PCM |
| 声道 | 单声道 |

若 API 返回的是裸 PCM 而非 WAV，脚本会自动补上正确的 RIFF 头再写盘。

---

## 错误对照

| 退出码 | 含义 | 处理 |
|---|---|---|
| `1` | 缺少必填参数 | 提供 `voice_description`、`text`、`output_path` |
| `1` | 未找到 API Key | 设置 `MIMO_API_KEY` 或配置 openclaw.json |
| `2` | API HTTP 错误 | 检查网络、Key |
| `2` | 返回结构异常 | 查看 stderr 中的原始响应 |
| `3` | 输出文件为空 / 未写出 | 确认父目录存在且可写 |
