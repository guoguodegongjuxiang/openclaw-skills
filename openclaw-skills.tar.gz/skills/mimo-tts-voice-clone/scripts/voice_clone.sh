#!/usr/bin/env bash
# voice_clone.sh — Clone a voice from a reference clip and synthesize speech
#                  with MiMo-V2.5-TTS-VoiceClone, saving the result as a WAV file.
#
# Usage:
#   voice_clone.sh <reference_audio> <text> <output_path> [style]
#
# Arguments:
#   reference_audio  Path to a reference voice clip (WAV/MP3/FLAC, a few seconds,
#                    ideally 5–15 s, clean single-speaker audio).
#   text             Text to speak in the cloned voice (required).
#                    Apply TTS normalization before passing.
#   output_path      Destination WAV file path (required). Parent dir must exist.
#   style            Optional natural-language style/emotion instruction, e.g.
#                    开心 / 语速慢 / 用尖锐刻薄的嗓音说话.
#                    The cloned timbre is preserved; only delivery changes.
#
# Environment variables:
#   MIMO_API_KEY            (required) MiMo platform API key. If unset, falls back
#                           to models.providers.xiaomi.apiKey in ~/.openclaw/openclaw.json
#   MIMO_API_BASE_URL       (optional) Override base URL (default https://api.xiaomimimo.com/v1)
#   MIMO_VOICECLONE_MODEL   (optional) Override model name (default mimo-v2.5-tts-voiceclone)
#
# Exit codes:
#   0  Success — WAV written to output_path
#   1  Missing required argument or reference file / API key not found
#   2  API request failed or returned an error
#   3  Output file could not be written

set -euo pipefail

# ── Arguments ──────────────────────────────────────────────────────────────
REFERENCE_AUDIO="${1:-}"
TEXT="${2:-}"
OUTPUT_PATH="${3:-}"
STYLE="${4:-}"

usage() {
  echo "Usage: $(basename "$0") <reference_audio> <text> <output_path> [style]" >&2
}

# ── Validation ─────────────────────────────────────────────────────────────
if [[ -z "$REFERENCE_AUDIO" ]]; then
  echo "Error: <reference_audio> is required" >&2; usage; exit 1
fi
if [[ -z "$TEXT" ]]; then
  echo "Error: <text> is required" >&2; usage; exit 1
fi
if [[ -z "$OUTPUT_PATH" ]]; then
  echo "Error: <output_path> is required" >&2; usage; exit 1
fi
if [[ ! -f "$REFERENCE_AUDIO" ]]; then
  echo "Error: reference audio file not found: $REFERENCE_AUDIO" >&2; exit 1
fi

# Resolve API key: env var → openclaw.json → error
if [[ -z "${MIMO_API_KEY:-}" ]]; then
  _OPENCLAW="$HOME/.openclaw/openclaw.json"
  if [[ -f "$_OPENCLAW" ]]; then
    MIMO_API_KEY=$(python3 -c "
import json, sys
try:
    d = json.load(open('$_OPENCLAW'))
    print(d['models']['providers']['xiaomi']['apiKey'])
except (KeyError, TypeError):
    sys.exit(1)
" 2>/dev/null) || true
  fi
fi
if [[ -z "${MIMO_API_KEY:-}" ]]; then
  echo "Error: MiMo API key not found." >&2
  echo "  Set MIMO_API_KEY env var, or add models.providers.xiaomi.apiKey to ~/.openclaw/openclaw.json" >&2
  exit 1
fi

TTS_ENDPOINT="${MIMO_API_BASE_URL:-https://api.xiaomimimo.com/v1}"
TTS_ENDPOINT="${TTS_ENDPOINT%/}/chat/completions"
MODEL="${MIMO_VOICECLONE_MODEL:-mimo-v2.5-tts-voiceclone}"

WORK_DIR=$(mktemp -d)
trap 'rm -rf "$WORK_DIR"' EXIT

# ── Resolve reference audio → data URI ──────────────────────────────────────
# The voice clone model only accepts WAV and MP3 reference audio. Other formats
# (FLAC, M4A, OGG, …) are rejected by the server with HTTP 400 "Param Incorrect",
# so reject them up front with a clear message instead of wasting an API call.
EXT="${REFERENCE_AUDIO##*.}"
EXT="${EXT,,}"
case "$EXT" in
  wav)  MIME="audio/wav" ;;
  mp3)  MIME="audio/mpeg" ;;
  *)
    echo "Error: unsupported reference audio format '.$EXT'. Only WAV and MP3 are supported." >&2
    echo "  Convert your reference clip to WAV or MP3 first (e.g. ffmpeg -i in.$EXT out.wav)." >&2
    exit 1
    ;;
esac
# Write the data URI to a temp file (not a shell variable): the base64 payload
# can be hundreds of KB, which overflows ARG_MAX if passed to jq via --arg.
REF_URI_FILE="$WORK_DIR/ref_data_uri.txt"
{ printf 'data:%s;base64,' "$MIME"; base64 -w 0 "$REFERENCE_AUDIO" 2>/dev/null || base64 "$REFERENCE_AUDIO" | tr -d '\n'; } > "$REF_URI_FILE"

# ── Build the text to speak (style is prepended as an inline instruction) ────
if [[ -n "$STYLE" ]]; then
  CONTENT="<style>${STYLE}</style>${TEXT}"
else
  CONTENT="${TEXT}"
fi

# ── Build request payload (voice clone format) ──────────────────────────────
# The voice clone model requires the reference clip in audio.voice (a data URI);
# the text to synthesize goes into the assistant message; audio.format=wav.
# --rawfile reads the (large) data URI from a file into $ref, avoiding ARG_MAX.
jq -n \
  --arg model "$MODEL" \
  --rawfile ref "$REF_URI_FILE" \
  --arg content "$CONTENT" \
  '{model: $model,
    messages: [
      {role: "assistant", content: $content}
    ],
    audio: {format: "wav", voice: $ref}}' > "$WORK_DIR/payload.json"

# ── Call the API (with retry on transient errors) ───────────────────────────
# The TTS backend occasionally returns transient failures (5xx, or 4xx with a
# generic "Request failed" message). Those succeed on retry. Hard errors (bad
# params, invalid key) are NOT retried — retrying is pointless and wastes time.
MAX_ATTEMPTS=3
HTTP_CODE=""
for attempt in $(seq 1 "$MAX_ATTEMPTS"); do
  HTTP_CODE=$(curl -s -w "%{http_code}" \
    -o "$WORK_DIR/resp.json" \
    --max-time 300 \
    -H "Content-Type: application/json" \
    -H "api-key: $MIMO_API_KEY" \
    -d @"$WORK_DIR/payload.json" \
    "$TTS_ENDPOINT") || HTTP_CODE="000"   # curl non-zero (network) → treat as retryable

  [[ "$HTTP_CODE" == "200" ]] && break

  RETRYABLE=0
  if [[ "$HTTP_CODE" =~ ^5 ]]; then
    RETRYABLE=1                       # any 5xx
  elif [[ "$HTTP_CODE" == "429" ]]; then
    RETRYABLE=1                       # rate limited
  elif [[ "$HTTP_CODE" =~ ^4 ]]; then
    if grep -qiE 'request failed|returned empty text|timeout|try again' "$WORK_DIR/resp.json"; then
      RETRYABLE=1
    fi
  elif [[ -z "$HTTP_CODE" || "$HTTP_CODE" == "000" ]]; then
    RETRYABLE=1                       # network/curl failure
  fi

  if [[ "$RETRYABLE" -eq 1 && "$attempt" -lt "$MAX_ATTEMPTS" ]]; then
    delay=$((2 ** (attempt - 1)))     # 1s, 2s, 4s ...
    echo "Warning: API returned HTTP ${HTTP_CODE:-000} (attempt ${attempt}/${MAX_ATTEMPTS}), retrying in ${delay}s..." >&2
    sleep "$delay"
    continue
  fi
  break
done

if [[ "$HTTP_CODE" != "200" ]]; then
  echo "Error: API returned HTTP $HTTP_CODE after ${attempt} attempt(s)" >&2
  cat "$WORK_DIR/resp.json" >&2
  exit 2
fi

# ── Decode audio data ───────────────────────────────────────────────────────
DECODE_SCRIPT="$WORK_DIR/decode.py"
cat > "$DECODE_SCRIPT" << 'PYEOF'
import json, base64, struct, io, sys

resp_path, out_path = sys.argv[1], sys.argv[2]

with open(resp_path) as f:
    data = json.load(f)

# Surface API-level errors
if data.get('error'):
    print(f"Error: API error: {data['error']}", file=sys.stderr)
    sys.exit(2)

try:
    audio = data['choices'][0]['message']['audio']
    raw = base64.b64decode(audio['data'])
except (KeyError, IndexError, TypeError) as e:
    print(f"Error: unexpected response shape — {e}", file=sys.stderr)
    print(json.dumps(data, ensure_ascii=False)[:400], file=sys.stderr)
    sys.exit(2)

# Handle both WAV (RIFF header present) and raw PCM
if raw[:4] == b'RIFF':
    wav_bytes = raw
else:
    # Wrap raw PCM: 24kHz, 16-bit, mono
    sr, bps, ch = 24000, 16, 1
    br = sr * ch * bps // 8
    buf = io.BytesIO()
    buf.write(b'RIFF')
    buf.write(struct.pack('<I', 36 + len(raw)))
    buf.write(b'WAVEfmt ')
    buf.write(struct.pack('<IHHIIHH', 16, 1, ch, sr, br, ch * bps // 8, bps))
    buf.write(b'data')
    buf.write(struct.pack('<I', len(raw)))
    buf.write(raw)
    wav_bytes = buf.getvalue()

with open(out_path, 'wb') as f:
    f.write(wav_bytes)

print(f"OK: {len(wav_bytes)} bytes written to {out_path}")
PYEOF

python3 "$DECODE_SCRIPT" "$WORK_DIR/resp.json" "$OUTPUT_PATH"

# ── Verify output ───────────────────────────────────────────────────────────
if [[ ! -s "$OUTPUT_PATH" ]]; then
  echo "Error: output file is empty or was not created: $OUTPUT_PATH" >&2
  exit 3
fi
