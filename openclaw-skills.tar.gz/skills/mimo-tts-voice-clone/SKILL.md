---
name: mimo-tts-voice-clone
description: "使用 MiMo-V2.5-TTS-VoiceClone 从一段参考录音复刻音色并合成语音，保存为 WAV。当用户提供参考音频并要求「用这个声音说…」「克隆/模仿这段录音的音色读…」「用我的声音念…」时使用；克隆后可叠加风格/情绪指令。"
homepage: https://mimo.xiaomi.com/mimo-v2-5-tts
metadata: { "openclaw": { "emoji": "🎙️", "requires": { "bins": ["jq", "curl", "python3"] }, "primaryEnv": "MIMO_API_KEY" } }
---

# MiMo 音色克隆 → WAV 文件

调用 MiMo-V2.5-TTS-VoiceClone 模型，从一段参考音频中高保真复刻目标音色，
再用该音色把指定文本合成为标准 WAV 文件（24 kHz，16-bit PCM，单声道）。
无需训练、无需标注，数秒参考音频即可；克隆后还能继续叠加自然语言风格指令。

---

## 何时使用

| 场景 | 用本 skill？ |
|---|---|
| 用户提供参考录音并说「用这个声音说…」 | ✅ 是 |
| 「克隆/复刻这个人的音色」「模仿这段录音读…」 | ✅ 是 |
| 「用我的声音念这段文字」（附带录音） | ✅ 是 |
| 中英文跨语言克隆（英文参考读英文、中文参考读中文） | ✅ 是 |
| 没有参考音频，只想用默认/预设音色合成语音 | ❌ 改用 `mimo-tts-wav` |
| 只是想分析/转录一段音频内容（不合成） | ❌ 改用 `mimo-omni` |

> 与 `mimo-tts-wav` 的区别：`mimo-tts-wav` 用预设音色或可选的 voice_sample
> 做普通合成；本 skill 专门面向**音色克隆**场景，必须提供参考音频，
> 调用的是 `mimo-v2.5-tts-voiceclone` 模型。

---

## 前置条件

| 要求 | 说明 |
|---|---|
| `jq` | 构造 JSON 请求体。安装：`brew install jq` / `apt install jq` |
| `python3` | 仅用标准库（json、base64、struct）解码音频 |
| `curl` | 发送请求，通常已预装 |
| API Key | 设置 `MIMO_API_KEY`，或在 `~/.openclaw/openclaw.json` 配置 `models.providers.xiaomi.apiKey`（脚本自动读取） |
| 参考音频 | 一段干净的单人录音，数秒即可（推荐 5–15 s），**仅支持 WAV/MP3**（其它格式服务端会拒） |

---

## 用法

```bash
bash {baseDir}/scripts/voice_clone.sh <reference_audio> <text> <output_path> [style]
```

### 参数

| # | 名称 | 必填 | 说明 |
|---|---|---|---|
| 1 | `reference_audio` | ✅ | 参考音频路径（**仅 WAV/MP3**）。干净的单人录音，数秒即可（推荐 5–15 s）。传入其它格式脚本会前置报错。 |
| 2 | `text` | ✅ | 要用克隆音色朗读的文本。传入前先做 TTS 文本规范化（见下文）。 |
| 3 | `output_path` | ✅ | 输出 WAV 文件路径，父目录需已存在。未指定时默认 `output.wav`。 |
| 4 | `style` | 可选 | 自然语言风格/情绪指令（如 `开心`、`语速慢`、`用尖锐刻薄的嗓音说话`）。音色保持不变，仅改变演绎方式。 |

### 环境变量

| 变量 | 默认值 | 说明 |
|---|---|---|
| `MIMO_API_KEY` | — | MiMo 平台 API Key（也可走 openclaw.json 自动解析） |
| `MIMO_API_BASE_URL` | `https://api.xiaomimimo.com/v1` | 覆盖 API 基础地址（会自动追加 `/chat/completions`） |
| `MIMO_VOICECLONE_MODEL` | `mimo-v2.5-tts-voiceclone` | 覆盖模型名 |

---

## 步骤

1. **拿到参考音频** —— 确认是一段干净、单人、数秒以上的录音。
   背景噪声越小、音色越突出，克隆效果越好。

2. **规范化文本** —— 对要朗读的 `text` 做 TTS 规范化（见下文），
   把数字、符号、markdown 转成自然口语。

3. **（可选）选择风格** —— 把任意自然语言风格短语作为第 4 个参数传入。
   克隆音色固定，风格自由叠加；省略则用参考音频本身的自然语气。

4. **运行脚本**：
   ```bash
   bash {baseDir}/scripts/voice_clone.sh 参考录音.wav "要朗读的内容" output.wav
   ```

5. **检查输出** —— 成功时脚本退出码为 `0`，并打印
   `OK: <N> bytes written to <path>`；出错时错误信息写到 stderr，退出码非零。

---

## 示例

```bash
# 最简单 —— 用参考音色朗读一句话
bash {baseDir}/scripts/voice_clone.sh ./my_voice.wav "风轻轻地吹过，带来了远方的花香。" output.wav

# 克隆 + 叠加风格指令（音色不变，演绎大幅转变）
bash {baseDir}/scripts/voice_clone.sh ./ref.wav \
  "你以为我是谁，也敢在这儿跟我耍横？" \
  scene.wav \
  "用尖锐刻薄的嗓音，带着得意感说话，语速放慢、加重语气，营造压迫感"

# 英文跨语言克隆（英文参考 → 英文输出）
bash {baseDir}/scripts/voice_clone.sh ./en_ref.wav \
  "Ignore the sirens, and just breathe with me. In, and out." \
  out_en.wav

# 情绪标签
bash {baseDir}/scripts/voice_clone.sh ./ref.mp3 "恭喜你获得了一等奖！" congrats.wav "开心激动"

# 接 ffmpeg 转成 MP3
bash {baseDir}/scripts/voice_clone.sh ./ref.wav "你好" /tmp/tmp.wav && \
  ffmpeg -i /tmp/tmp.wav out.mp3
```

---

## 风格指令指南

`style` 接受**任意自然语言短语**，模型自由解读，没有固定取值。
克隆出的音色会完整继承系列模型的控制能力 —— 音色固定，风格自由。

| 类别 | 示例 |
|---|---|
| 情绪 | `开心` / `悲伤` / `生气` / `平静` / `深情款款` |
| 语气节奏 | `语速慢` / `语速快` / `悄悄话` / `清晰有力` |
| 角色演绎 | `像个大将军` / `像个小孩` / `老成稳重` |
| 复杂指令 | `用尖锐刻薄的嗓音，提到大人物时故意放慢语速并加重语气` |
| 英文风格 | `Broadcast this like a blistering post-match pundit, fast and openly fed up` |

省略 `style` 参数即用参考音频本身的自然语气。

---

## TTS 文本规范化

把文本传给脚本前先预处理，将不发音的符号替换为自然口语
（中文为主，英文文本按英文处理）。

### 数字
| 输入 | 朗读 |
|---|---|
| `3` | 三 |
| `3.14` | 三点一四 |
| `1/3` | 三分之一 |
| `14:30` | 下午两点半 |
| `95%` | 百分之九十五 |
| `2024`（年份） | 二零二四年 |

### 常见符号
| 符号 | 朗读 |
|---|---|
| `+` | 加 |
| `-` | 减 |
| `×` / `*` | 乘以 |
| `÷` / `/` | 除以 |
| `=` | 等于 |
| `>` / `<` | 大于 / 小于 |
| `%` | 百分之… |
| `~` | 大约 |
| `...` / `…` | 等等 |

### 格式残留
- 去掉 markdown（`**加粗**`、`# 标题`、`` `代码` ``、`- 列表`）
- 编号列表转成口语：「有三点，第一……第二……第三……」
- 表格转成描述关键数值的句子

---

## 跨语言克隆

- 支持中英文跨语言音色克隆。
- 英文参考音频可直接生成英文输出，中文参考音频生成中文输出。
- 语言切换不影响音色特征的还原精度。
- 文本规范化按目标语言处理（中文文本走中文规则，英文文本走英文）。

---

## 请求格式说明

参考音频以 data URI 形式放进顶层 `audio.voice` 字段（voice clone 模型的必填项），
要朗读的文本放进 `assistant` 消息，`audio.format` 请求 WAV 输出。

```json
{
  "model": "mimo-v2.5-tts-voiceclone",
  "messages": [
    {"role": "assistant", "content": "<style>风格指令</style>要朗读的文本"}
  ],
  "audio": {"format": "wav", "voice": "data:audio/wav;base64,<参考音频>"}
}
```

> 注：参考音频 base64 后可达数百 KB，脚本通过临时文件 + `jq --rawfile` 构造
> 请求体，避免命令行参数超长（ARG_MAX）。

---

## 输出格式

脚本始终写出标准 RIFF WAV 文件：

| 属性 | 值 |
|---|---|
| 格式 | WAV (RIFF) |
| 采样率 | 24 000 Hz |
| 位深 | 16-bit PCM |
| 声道 | 单声道 |

若 API 返回的是裸 PCM 而非 WAV，脚本会自动补上正确的 RIFF 头再写盘。

---

## 错误对照

| 退出码 | 含义 | 处理 |
|---|---|---|
| `1` | 缺少必填参数 | 提供 `reference_audio`、`text`、`output_path` |
| `1` | 参考音频文件不存在 | 检查第 1 个参数的路径 |
| `1` | 未找到 API Key | 设置 `MIMO_API_KEY` 或配置 openclaw.json |
| `2` | API HTTP 错误 | 检查网络、Key、参考音频大小（base64 上限 10MB） |
| `2` | 返回结构异常 | 查看 stderr 中的原始响应 |
| `3` | 输出文件为空 / 未写出 | 确认父目录存在且可写 |
