# OpenClaw ↔ Hermes MCP 对接方案

## 架构概览

```
┌─────────────────┐     HTTP/SSE      ┌──────────────────┐     MCP JSON-RPC     ┌──────────────────┐
│   Mimo Claw     │ ───────────────→  │   Bridge 中转层   │ ──────────────────→  │   Hermes MCP     │
│   (OpenClaw)    │ ←───────────────  │   (本脚本)        │ ←──────────────────  │   Gateway        │
└─────────────────┘                   └──────────────────┘                      └──────────────────┘
                                              │
                                              │  承载运行
                                              ▼
                                      ┌──────────────────┐
                                      │    QQ Bot        │
                                      │  消息监听/应答    │
                                      │  群组管理         │
                                      └──────────────────┘
```

**通信链路**：OpenClaw → Bridge (HTTP) → Hermes (MCP) → QQ 平台

---

## 文件结构

```
hermes-bridge/
├── package.json
├── config/
│   ├── hermes.config.json      # Hermes 连接配置
│   ├── qq-bot.config.json      # QQ 机器人配置
│   ├── hermes-tools.json       # Hermes MCP 工具定义（含 MiMo Code）
│   └── mimo-code.config.json   # MiMo Code 适配配置
├── src/
│   ├── bridge.js               # 核心中转层（HTTP/SSE）
│   ├── hermes-client.js        # MCP 协议客户端
│   ├── mimo-code-adapter.js    # MiMo Code CLI/API 双通道适配
│   ├── qq-bot.js               # QQ 机器人主进程
│   └── group-manager.js        # 群组管理模块
├── data/                       # 运行时数据（自动创建）
└── README.md
```

---

## 部署步骤

### 1. 安装依赖

```bash
cd hermes-bridge
npm install
```

### 2. 配置 Hermes 连接

编辑 `config/hermes.config.json`：

```json
{
  "hermesEndpoint": "http://localhost:9100/mcp",
  "hermesToken": "your-token-if-needed",
  "bridgePort": 3900,
  "timeoutMs": 30000,
  "transport": "http"
}
```

- `hermesEndpoint`：你的 Hermes MCP 网关地址
- `hermesToken`：认证 token（如果 Hermes 有鉴权）
- `bridgePort`：中转层 HTTP 端口

### 3. 配置 QQ 机器人

编辑 `config/qq-bot.config.json`：

```json
{
  "selfId": "123456789",
  "adminQQ": "987654321",
  "groups": [111111, 222222],
  "autoReply": true,
  "keywordRules": [...]
}
```

- `selfId`：机器人 QQ 号
- `adminQQ`：管理员 QQ 号（可用 /ban /kick 等命令）
- `groups`：白名单群号，空数组 = 监听所有群

### 4. 注册 Hermes MCP 工具

将 `config/hermes-tools.json` 中的工具定义注册到你的 Hermes 网关。具体方式取决于你的 Hermes 实现，通常是：

```bash
# 方式 A：Hermes 启动时自动扫描 tools 目录
cp config/hermes-tools.json /path/to/hermes/tools/qq-bot.json

# 方式 B：通过 Hermes CLI 注册
hermes tool register --file config/hermes-tools.json

# 方式 C：通过 API 注册
curl -X POST http://localhost:9100/tools/register \
  -H "Content-Type: application/json" \
  -d @config/hermes-tools.json
```

### 5. 启动

```bash
# 启动中转层
npm start

# 启动 QQ 机器人（在同一目录）
npm run qqbot

# 或用 PM2 守护进程
pm2 start src/bridge.js --name hermes-bridge
pm2 start src/qq-bot.js --name qq-bot
```

---

## API 接口

### 中转层 HTTP 接口

| 端点 | 方法 | 说明 |
|------|------|------|
| `/health` | GET | 健康检查 |
| `/sse/:sessionId` | GET | SSE 长连接（事件推送） |
| `/tools/call` | POST | 调用 Hermes MCP 工具 |
| `/tools/list` | POST | 列出可用工具 |
| `/hermes/callback` | POST | Hermes 事件回调 |
| `/mimo/execute` | POST | MiMo Code 编程任务执行 |
| `/mimo/init` | POST | MiMo Code 项目初始化 |
| `/mimo/memory` | POST | 获取 MiMo Code 项目记忆 |

### 调用示例

```bash
# 列出工具
curl -X POST http://localhost:3900/tools/list \
  -H "Content-Type: application/json" \
  -d '{"sessionId":"test"}'

# 发送 QQ 消息
curl -X POST http://localhost:3900/tools/call \
  -H "Content-Type: application/json" \
  -d '{
    "sessionId": "test",
    "tool": "qq_send_message",
    "arguments": {
      "target": "group_123456",
      "message": "Hello from OpenClaw!"
    }
  }'
```

---

## QQ 管理命令

在 QQ 群内发送（需 adminQQ 权限）：

| 命令 | 说明 |
|------|------|
| `/ban @user 30` | 禁言 30 分钟 |
| `/unban @user` | 解除禁言 |
| `/kick @user` | 踢出群 |
| `/mute` | 全员禁言 |
| `/unmute` | 解除全员禁言 |
| `/welcome 新的欢迎语` | 更新欢迎语 |

---

## 关键词规则配置

`qq-bot.config.json` 中的 `keywordRules`：

```json
{
  "name": "规则名",
  "pattern": "正则表达式",
  "action": "reply | forward | ban",
  "reply": "回复内容（action=reply 时）",
  "task": "任务名（action=forward 时）",
  "duration": 600
}
```

- `reply`：直接回复匹配的消息
- `forward`：转发到 Hermes 调度（可用于 AI 对话、任务派发）
- `ban`：自动禁言（适合广告过滤）

---

## MiMo Code 集成

Bridge 内置 MiMo Code 适配器，支持两种模式：

### CLI 模式（推荐，本地部署）

需先安装 MiMo Code：
```bash
curl -fsSL https://mimo.xiaomi.com/install | bash
```

编辑 `config/mimo-code.config.json`：
```json
{
  "mode": "cli",
  "cliPath": "mimo",
  "cwd": "/path/to/your/project"
}
```

### API 模式（远程调度）

```json
{
  "mode": "api",
  "apiEndpoint": "https://api.mimo.xiaomi.com/v1",
  "apiKey": "your-mimo-api-key",
  "model": "MiMo-V2.5-Pro"
}
```

### 调用方式

```bash
# 执行编程任务
curl -X POST http://localhost:3900/mimo/execute \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "给 main.py 添加日志功能",
    "cwd": "/path/to/project",
    "maxMode": true
  }'

# 初始化项目（生成 AGENTS.md）
curl -X POST http://localhost:3900/mimo/init \
  -d '{"cwd": "/path/to/project"}'

# 获取项目记忆
curl -X POST http://localhost:3900/mimo/memory \
  -d '{"cwd": "/path/to/project", "type": "memory"}'
```

### Max Mode 与 Goal

- **MaxMode**: 并行 5 候选选优，提升复杂任务准确率（token 消耗 ×5）
- **Goal**: 自然语言完成条件验证，防止过早终止

```bash
curl -X POST http://localhost:3900/mimo/execute \
  -d '{
    "prompt": "将项目从 JS 迁移到 TS",
    "maxMode": true,
    "goal": "所有 .js 文件已删除，所有测试通过，tsc 无报错"
  }'
```

---

## 与 Mimo Claw 集成

在 OpenClaw 中通过 HTTP 调用 Bridge：

```bash
# OpenClaw exec 中调用
curl -X POST http://localhost:3900/tools/call \
  -d '{"tool":"qq_send_message","arguments":{"target":"group_123","message":"来自Mimo的消息"}}'
```

或在 OpenClaw 配置中添加 webhook 回调，让 Hermes 事件自动推送到 Mimo。
