// ============================================================
// OpenClaw (Mimo Claw) ↔ Hermes MCP 双向通信中转层
// ============================================================
// 架构：
//   OpenClaw  --HTTP/SSE-->  Bridge  --MCP JSON-RPC-->  Hermes
//   OpenClaw  <--SSE----     Bridge  <--MCP Response--  Hermes
// ============================================================

import express from "express";
import { randomUUID } from "crypto";
import { EventEmitter } from "events";
import { loadConfig, mcpRequest, mcpNotify } from "./hermes-client.js";
import { createMiMoCodeAdapter } from "./mimo-code-adapter.js";
import { readFileSync, existsSync } from "fs";
import { resolve } from "path";

const config = loadConfig();
const app = express();
app.use(express.json({ limit: "10mb" }));

// ── 会话管理 ──────────────────────────────────────────────
const sessions = new Map();

class BridgeSession extends EventEmitter {
  constructor(id) {
    super();
    this.id = id;
    this.createdAt = Date.now();
    this.pending = new Map(); // reqId → { resolve, reject, timer }
    this.sseClients = new Set();
  }

  // 向 Hermes 发送请求，等待响应
  async callHermes(method, params = {}) {
    const reqId = randomUUID();
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(reqId);
        reject(new Error(`Hermes timeout: ${method}`));
      }, config.timeoutMs || 30000);

      this.pending.set(reqId, { resolve, reject, timer });

      mcpRequest(method, params, reqId).catch((err) => {
        clearTimeout(timer);
        this.pending.delete(reqId);
        reject(err);
      });
    });
  }

  // Hermes 响应路由
  handleResponse(id, result, error) {
    const p = this.pending.get(id);
    if (!p) return;
    clearTimeout(p.timer);
    this.pending.delete(id);
    if (error) p.reject(new Error(error.message || JSON.stringify(error)));
    else p.resolve(result);
  }

  // SSE 推送到 OpenClaw
  pushEvent(event) {
    const data = `data: ${JSON.stringify(event)}\n\n`;
    for (const res of this.sseClients) {
      res.write(data);
    }
  }
}

function getSession(sessionId) {
  if (!sessions.has(sessionId)) {
    sessions.set(sessionId, new BridgeSession(sessionId));
  }
  return sessions.get(sessionId);
}

// ── SSE 通道：OpenClaw 长连接接收事件 ─────────────────────
app.get("/sse/:sessionId", (req, res) => {
  const session = getSession(req.params.sessionId);
  res.writeHead(200, {
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache",
    Connection: "keep-alive",
  });
  res.write(`data: ${JSON.stringify({ type: "connected", session: session.id })}\n\n`);
  session.sseClients.add(res);
  req.on("close", () => session.sseClients.delete(res));
});

// ── MCP 工具调用入口（OpenClaw → Hermes）────────────────
app.post("/tools/call", async (req, res) => {
  const { sessionId = "default", tool, arguments: args } = req.body;
  const session = getSession(sessionId);

  try {
    // 1. 先确保 Hermes 已初始化
    if (!session._initialized) {
      await session.callHermes("initialize", {
        protocolVersion: "2024-11-05",
        capabilities: {},
        clientInfo: { name: "openclaw-bridge", version: "1.0.0" },
      });
      session._initialized = true;
    }

    // 2. 调用 Hermes MCP tool
    const result = await session.callHermes("tools/call", {
      name: tool,
      arguments: args || {},
    });

    res.json({ ok: true, result });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// ── 列出 Hermes 可用工具 ─────────────────────────────────
app.post("/tools/list", async (req, res) => {
  const { sessionId = "default" } = req.body;
  const session = getSession(sessionId);

  try {
    if (!session._initialized) {
      await session.callHermes("initialize", {
        protocolVersion: "2024-11-05",
        capabilities: {},
        clientInfo: { name: "openclaw-bridge", version: "1.0.0" },
      });
      session._initialized = true;
    }
    const result = await session.callHermes("tools/list", {});
    res.json({ ok: true, tools: result.tools || [] });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// ── Hermes 事件回调入口（Hermes → OpenClaw）──────────────
app.post("/hermes/callback", (req, res) => {
  const { sessionId = "default", method, params, id, result, error } = req.body;
  const session = getSession(sessionId);

  // 如果是响应
  if (id && (result || error)) {
    session.handleResponse(id, result, error);
  }

  // 如果是通知/事件
  if (method) {
    session.pushEvent({ method, params, ts: Date.now() });
  }

  res.json({ ok: true });
});

// ── 健康检查 ─────────────────────────────────────────────
app.get("/health", (req, res) => {
  res.json({
    status: "ok",
    uptime: process.uptime(),
    sessions: sessions.size,
    hermesEndpoint: config.hermesEndpoint,
  });
});

// ── MiMo Code 工具路由 ──────────────────────────────────
const mimoAdapter = createMiMoCodeAdapter();

// 注册 MiMo Code 工具到 Hermes（启动时自动注册）
async function registerMiMoTools() {
  const toolsPath = resolve(process.cwd(), "config/hermes-tools.json");
  if (existsSync(toolsPath)) {
    const tools = JSON.parse(readFileSync(toolsPath, "utf-8"));
    try {
      await mcpRequest("tools/register", { tools: tools.tools });
      console.log("[Bridge] MiMo Code 工具已注册到 Hermes");
    } catch (e) {
      console.warn("[Bridge] 工具注册跳过（Hermes 可能不支持动态注册）:", e.message);
    }
  }
}

// 本地工具处理（不经过 Hermes，直接本地执行）
app.post("/mimo/execute", async (req, res) => {
  const { prompt, cwd, model, maxMode, goal } = req.body;
  try {
    const result = await mimoAdapter.execute(prompt, { cwd, model, maxMode, goal });
    res.json({ ok: true, ...result });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.post("/mimo/init", async (req, res) => {
  const { cwd } = req.body;
  try {
    const result = await mimoAdapter.initProject(cwd);
    res.json({ ok: true, ...result });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.post("/mimo/memory", async (req, res) => {
  const { cwd, type = "memory" } = req.body;
  try {
    let content;
    if (type === "checkpoint") {
      content = await mimoAdapter.getCheckpoint(cwd);
    } else {
      content = await mimoAdapter.getMemory(cwd);
    }
    res.json({ ok: true, content });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// ── 启动 ─────────────────────────────────────────────────
const PORT = config.bridgePort || 3900;
app.listen(PORT, async () => {
  console.log(`[Bridge] OpenClaw ↔ Hermes 中转层已启动`);
  console.log(`[Bridge] 监听端口: ${PORT}`);
  console.log(`[Bridge] Hermes 端点: ${config.hermesEndpoint}`);
  console.log(`[Bridge] SSE 通道: http://localhost:${PORT}/sse/:sessionId`);
  console.log(`[Bridge] 工具调用: POST http://localhost:${PORT}/tools/call`);
  console.log(`[Bridge] MiMo Code: POST http://localhost:${PORT}/mimo/execute`);
  await registerMiMoTools();
});
