// ============================================================
// QQ 机器人 — 基于 Hermes MCP 的消息监听/应答/群管
// ============================================================
// 运行方式：node src/qq-bot.js
// 进程全部由 Hermes 承载，Mimo 只负责生成代码
// ============================================================

import { loadConfig, mcpRequest, mcpNotify } from "./hermes-client.js";
import { readFileSync, existsSync } from "fs";
import { resolve } from "path";

const config = loadConfig();
const QQ_CONFIG_PATH = resolve(process.cwd(), "config/qq-bot.config.json");

function loadQQConfig() {
  if (existsSync(QQ_CONFIG_PATH)) {
    return JSON.parse(readFileSync(QQ_CONFIG_PATH, "utf-8"));
  }
  return {
    groups: [],
    adminQQ: "",
    autoReply: true,
    keywordRules: [],
    welcomeMessage: "你好！我是穹络助手 🤖",
  };
}

// ── 消息队列 ──────────────────────────────────────────────
const messageQueue = [];
let processing = false;

// ── 初始化 Hermes MCP 连接 ───────────────────────────────
async function initHermes() {
  console.log("[QQ-Bot] 正在连接 Hermes MCP...");

  const initResult = await mcpRequest("initialize", {
    protocolVersion: "2024-11-05",
    capabilities: { roots: { listChanged: true } },
    clientInfo: { name: "qq-bot-hermes", version: "1.0.0" },
  });

  console.log("[QQ-Bot] Hermes 已连接:", initResult.serverInfo?.name || "unknown");
  await mcpNotify("notifications/initialized", {});
  return initResult;
}

// ── 调用 Hermes QQ 工具 ──────────────────────────────────
async function callQQTool(tool, args) {
  return mcpRequest("tools/call", { name: tool, arguments: args });
}

// ── 消息处理引擎 ─────────────────────────────────────────
async function processMessage(event) {
  const qqCfg = loadQQConfig();
  const { group_id, user_id, message, message_type, raw_message } = event;

  // 1. 群白名单过滤
  if (message_type === "group" && qqCfg.groups.length > 0) {
    if (!qqCfg.groups.includes(group_id)) return;
  }

  // 2. 关键词规则匹配
  for (const rule of qqCfg.keywordRules) {
    if (rule.pattern && new RegExp(rule.pattern, "i").test(raw_message)) {
      console.log(`[QQ-Bot] 命中规则: ${rule.name} | 群:${group_id} 用户:${user_id}`);

      if (rule.action === "reply") {
        await callQQTool("qq_send_message", {
          target: message_type === "group" ? `group_${group_id}` : `private_${user_id}`,
          message: rule.reply,
        });
      } else if (rule.action === "forward") {
        // 转发到 Hermes 调度
        await callQQTool("hermes_dispatch", {
          task: rule.task,
          context: { group_id, user_id, message: raw_message },
        });
      } else if (rule.action === "ban" && rule.duration) {
        await callQQTool("qq_ban_user", {
          group_id,
          user_id,
          duration: rule.duration,
        });
      }
      return;
    }
  }

  // 3. @机器人 自动回复
  if (raw_message?.includes(`[CQ:at,qq=${config.selfId || "0"}]`)) {
    const reply = await generateReply(raw_message, { group_id, user_id });
    await callQQTool("qq_send_message", {
      target: `group_${group_id}`,
      message: reply,
    });
    return;
  }

  // 4. 私聊自动回复
  if (message_type === "private" && qqCfg.autoReply) {
    const reply = await generateReply(raw_message, { user_id });
    await callQQTool("qq_send_message", {
      target: `private_${user_id}`,
      message: reply,
    });
  }
}

// ── 回复生成（通过 Hermes 调度 Mimo）─────────────────────
async function generateReply(message, context) {
  try {
    const result = await callQQTool("hermes_chat", {
      message,
      context,
      systemPrompt: "你是穹络项目QQ助手，简洁友好地回复。",
    });
    return result?.content?.[0]?.text || "收到！";
  } catch {
    return "收到！（Hermes 暂时不可用）";
  }
}

// ── 群管理命令 ───────────────────────────────────────────
async function handleAdminCommand(event) {
  const qqCfg = loadQQConfig();
  const { group_id, user_id, raw_message } = event;

  // 只有管理员可用
  if (user_id !== qqCfg.adminQQ) return false;

  const cmd = raw_message?.trim();

  // /ban @user 时间
  const banMatch = cmd?.match(/^\/ban\s+\[CQ:at,qq=(\d+)\]\s*(\d+)?/);
  if (banMatch) {
    const [, targetQQ, duration = "60"] = banMatch;
    await callQQTool("qq_ban_user", {
      group_id,
      user_id: targetQQ,
      duration: parseInt(duration) * 60,
    });
    await callQQTool("qq_send_message", {
      target: `group_${group_id}`,
      message: `已禁言 ${targetQQ} ${duration} 分钟`,
    });
    return true;
  }

  // /unban @user
  const unbanMatch = cmd?.match(/^\/unban\s+\[CQ:at,qq=(\d+)\]/);
  if (unbanMatch) {
    await callQQTool("qq_ban_user", {
      group_id,
      user_id: unbanMatch[1],
      duration: 0,
    });
    await callQQTool("qq_send_message", {
      target: `group_${group_id}`,
      message: `已解除 ${unbanMatch[1]} 的禁言`,
    });
    return true;
  }

  // /kick @user
  const kickMatch = cmd?.match(/^\/kick\s+\[CQ:at,qq=(\d+)\]/);
  if (kickMatch) {
    await callQQTool("qq_kick_user", {
      group_id,
      user_id: kickMatch[1],
    });
    await callQQTool("qq_send_message", {
      target: `group_${group_id}`,
      message: `已踢出 ${kickMatch[1]}`,
    });
    return true;
  }

  // /mute 全员禁言
  if (cmd === "/mute") {
    await callQQTool("qq_group_mute", { group_id, mute: true });
    return true;
  }

  // /unmute 解除全员禁言
  if (cmd === "/unmute") {
    await callQQTool("qq_group_mute", { group_id, mute: false });
    return true;
  }

  // /welcome 设置欢迎语
  const welcomeMatch = cmd?.match(/^\/welcome\s+(.+)/);
  if (welcomeMatch) {
    const qqCfgPath = QQ_CONFIG_PATH;
    const cfg = loadQQConfig();
    cfg.welcomeMessage = welcomeMatch[1];
    const { writeFileSync } = await import("fs");
    writeFileSync(qqCfgPath, JSON.stringify(cfg, null, 2));
    await callQQTool("qq_send_message", {
      target: `group_${group_id}`,
      message: "✅ 欢迎语已更新",
    });
    return true;
  }

  return false;
}

// ── 轮询 Hermes 事件流 ───────────────────────────────────
async function pollEvents() {
  console.log("[QQ-Bot] 开始监听 QQ 事件...");

  while (true) {
    try {
      // 通过 Hermes 获取 QQ 消息事件
      const events = await callQQTool("qq_poll_events", {
        timeout: 30000,
        types: ["message", "notice", "request"],
      });

      if (events?.items) {
        for (const event of events.items) {
          // 先检查管理命令
          if (event.post_type === "message") {
            const handled = await handleAdminCommand(event);
            if (!handled) {
              await processMessage(event);
            }
          }

          // 新成员入群欢迎
          if (event.post_type === "notice" && event.sub_type === "increase") {
            const qqCfg = loadQQConfig();
            await callQQTool("qq_send_message", {
              target: `group_${event.group_id}`,
              message: `${qqCfg.welcomeMessage}\n欢迎 [CQ:at,qq=${event.user_id}] 加入！`,
            });
          }
        }
      }
    } catch (err) {
      console.error("[QQ-Bot] 事件轮询错误:", err.message);
      await new Promise((r) => setTimeout(r, 5000));
    }
  }
}

// ── 主入口 ───────────────────────────────────────────────
async function main() {
  console.log("╔══════════════════════════════════════╗");
  console.log("║   QQ Bot — Hermes MCP 承载运行       ║");
  console.log("╚══════════════════════════════════════╝");

  await initHermes();
  await pollEvents();
}

main().catch((err) => {
  console.error("[QQ-Bot] 致命错误:", err);
  process.exit(1);
});
