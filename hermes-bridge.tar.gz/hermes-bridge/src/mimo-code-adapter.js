// ============================================================
// MiMo Code 适配器 — 通过 CLI/API 双通道调度 MiMo Code
// ============================================================
// 支持两种模式：
//   1. CLI 模式：调用 `mimo` 命令行（适合本地部署）
//   2. API 模式：直接调用 MiMo API（适合远程调度）
// ============================================================

import { execSync, spawn } from "child_process";
import { loadConfig } from "./hermes-client.js";
import { readFileSync, existsSync } from "fs";
import { resolve } from "path";

const MIMO_CONFIG_PATH = resolve(process.cwd(), "config/mimo-code.config.json");

function loadMimoConfig() {
  if (existsSync(MIMO_CONFIG_PATH)) {
    return JSON.parse(readFileSync(MIMO_CONFIG_PATH, "utf-8"));
  }
  return {
    mode: "cli",           // "cli" | "api"
    cliPath: "mimo",        // MiMo Code CLI 路径
    apiEndpoint: "https://api.mimo.xiaomi.com/v1",
    apiKey: "",             // MiMo API Key（API 模式用）
    model: "MiMo-V2.5-Pro",
    maxTokens: 32768,
    timeoutMs: 120000,
    cwd: process.cwd(),    // 默认工作目录
    env: {},
  };
}

// ── CLI 模式：调用 mimo 命令行 ────────────────────────────
export class MiMoCodeCLI {
  constructor(config) {
    this.config = config;
    this.cliPath = config.cliPath || "mimo";
  }

  /**
   * 执行 MiMo Code 任务（CLI 模式）
   * @param {string} prompt - 任务描述
   * @param {object} opts - 选项
   * @returns {Promise<{output: string, success: boolean, files?: string[]}>}
   */
  async execute(prompt, opts = {}) {
    const {
      cwd = this.config.cwd,
      timeout = this.config.timeoutMs || 120000,
      model,
      maxMode = false,
      goal,
    } = opts;

    const args = [];

    // 非交互模式，直接执行 prompt
    args.push("--print");        // 非交互，输出后退出
    args.push("--output-format", "text");

    if (model) {
      args.push("--model", model);
    }

    if (maxMode) {
      args.push("--max-mode");
    }

    if (goal) {
      args.push("--goal", goal);
    }

    // prompt 通过 stdin 传入
    args.push("--");

    return new Promise((resolve, reject) => {
      const proc = spawn(this.cliPath, args, {
        cwd,
        env: { ...process.env, ...this.config.env },
        stdio: ["pipe", "pipe", "pipe"],
        timeout,
      });

      let stdout = "";
      let stderr = "";

      proc.stdout.on("data", (d) => (stdout += d.toString()));
      proc.stderr.on("data", (d) => (stderr += d.toString()));

      proc.stdin.write(prompt);
      proc.stdin.end();

      proc.on("close", (code) => {
        // 提取被修改的文件列表
        const files = this._extractFiles(stdout);

        resolve({
          output: stdout.trim(),
          success: code === 0,
          files,
          stderr: stderr.trim(),
          exitCode: code,
        });
      });

      proc.on("error", (err) => {
        reject(new Error(`MiMo Code CLI 错误: ${err.message}`));
      });
    });
  }

  /**
   * 初始化项目（等同于 /init）
   */
  async initProject(cwd) {
    return new Promise((resolve, reject) => {
      const proc = spawn(this.cliPath, ["--print", "--output-format", "text", "--", "/init"], {
        cwd,
        env: { ...process.env, ...this.config.env },
        stdio: ["pipe", "pipe", "pipe"],
        timeout: 60000,
      });

      let stdout = "";
      proc.stdout.on("data", (d) => (stdout += d.toString()));
      proc.stdin.write("\n");
      proc.stdin.end();

      proc.on("close", (code) => {
        resolve({ output: stdout.trim(), success: code === 0 });
      });
      proc.on("error", reject);
    });
  }

  /**
   * 获取项目记忆
   */
  async getMemory(cwd) {
    const memoryPath = resolve(cwd || this.config.cwd, "MEMORY.md");
    if (existsSync(memoryPath)) {
      return readFileSync(memoryPath, "utf-8");
    }
    return null;
  }

  /**
   * 获取会话检查点
   */
  async getCheckpoint(cwd) {
    const cpPath = resolve(cwd || this.config.cwd, ".mimo", "checkpoint.md");
    if (existsSync(cpPath)) {
      return readFileSync(cpPath, "utf-8");
    }
    return null;
  }

  // 从输出中提取文件路径
  _extractFiles(output) {
    const patterns = [
      /(?:wrote?|created?|modified?|edited?|updated?)\s+[`"']?([^\s`"']+)[`"']?/gi,
      /diff\s+--git\s+a\/(\S+)/g,
    ];
    const files = new Set();
    for (const pat of patterns) {
      let m;
      while ((m = pat.exec(output))) {
        files.add(m[1]);
      }
    }
    return [...files];
  }
}

// ── API 模式：直接调用 MiMo API ──────────────────────────
export class MiMoCodeAPI {
  constructor(config) {
    this.config = config;
    this.endpoint = config.apiEndpoint || "https://api.mimo.xiaomi.com/v1";
    this.apiKey = config.apiKey;
  }

  /**
   * 通过 MiMo API 执行编码任务
   */
  async execute(prompt, opts = {}) {
    const { model = this.config.model, maxTokens = this.config.maxTokens } = opts;

    const body = {
      model,
      messages: [
        {
          role: "system",
          content: this._buildSystemPrompt(opts),
        },
        { role: "user", content: prompt },
      ],
      max_tokens: maxTokens,
      tools: this._getToolDefs(),
    };

    const res = await fetch(`${this.endpoint}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${this.apiKey}`,
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(this.config.timeoutMs || 120000),
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`MiMo API ${res.status}: ${text.slice(0, 200)}`);
    }

    const data = await res.json();
    const choice = data.choices?.[0];

    return {
      output: choice?.message?.content || "",
      success: choice?.finish_reason === "stop",
      usage: data.usage,
      toolCalls: choice?.message?.tool_calls || [],
    };
  }

  _buildSystemPrompt(opts) {
    return `你是 MiMo Code 编程助手。你在一个终端环境中工作，可以读写文件、执行命令。
工作目录: ${opts.cwd || this.config.cwd}
请直接完成用户的编程任务，输出修改后的文件内容和执行结果。`;
  }

  _getToolDefs() {
    return [
      {
        type: "function",
        function: {
          name: "read_file",
          description: "读取文件内容",
          parameters: {
            type: "object",
            properties: { path: { type: "string" } },
            required: ["path"],
          },
        },
      },
      {
        type: "function",
        function: {
          name: "write_file",
          description: "写入文件",
          parameters: {
            type: "object",
            properties: {
              path: { type: "string" },
              content: { type: "string" },
            },
            required: ["path", "content"],
          },
        },
      },
      {
        type: "function",
        function: {
          name: "exec_command",
          description: "执行 shell 命令",
          parameters: {
            type: "object",
            properties: { command: { type: "string" } },
            required: ["command"],
          },
        },
      },
    ];
  }
}

// ── 统一调度入口 ──────────────────────────────────────────
export function createMiMoCodeAdapter() {
  const config = loadMimoConfig();
  if (config.mode === "api") {
    return new MiMoCodeAPI(config);
  }
  return new MiMoCodeCLI(config);
}
