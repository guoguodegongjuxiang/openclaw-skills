// ============================================================
// 群组管理模块 — 封装 QQ 群管操作
// ============================================================

import { loadConfig, mcpRequest } from "./hermes-client.js";
import { readFileSync, writeFileSync, existsSync } from "fs";
import { resolve } from "path";

const GROUPS_DB = resolve(process.cwd(), "data/groups.json");

// ── 群组数据持久化 ────────────────────────────────────────
function loadGroups() {
  if (existsSync(GROUPS_DB)) {
    return JSON.parse(readFileSync(GROUPS_DB, "utf-8"));
  }
  return {};
}

function saveGroups(groups) {
  writeFileSync(GROUPS_DB, JSON.stringify(groups, null, 2));
}

// ── 群管 API 封装 ────────────────────────────────────────
export class GroupManager {
  // 获取群列表
  async listGroups() {
    const result = await mcpRequest("tools/call", {
      name: "qq_get_group_list",
      arguments: {},
    });
    return result?.content || [];
  }

  // 获取群成员列表
  async getMembers(groupId) {
    const result = await mcpRequest("tools/call", {
      name: "qq_get_group_members",
      arguments: { group_id: groupId },
    });
    return result?.content || [];
  }

  // 设置群名片
  async setCard(groupId, userId, card) {
    return mcpRequest("tools/call", {
      name: "qq_set_group_card",
      arguments: { group_id: groupId, user_id: userId, card },
    });
  }

  // 禁言
  async ban(groupId, userId, duration = 60) {
    return mcpRequest("tools/call", {
      name: "qq_ban_user",
      arguments: { group_id: groupId, user_id: userId, duration },
    });
  }

  // 解禁
  async unban(groupId, userId) {
    return this.ban(groupId, userId, 0);
  }

  // 踢人
  async kick(groupId, userId) {
    return mcpRequest("tools/call", {
      name: "qq_kick_user",
      arguments: { group_id: groupId, user_id: userId },
    });
  }

  // 全员禁言开关
  async muteAll(groupId, mute = true) {
    return mcpRequest("tools/call", {
      name: "qq_group_mute",
      arguments: { group_id: groupId, mute },
    });
  }

  // 设置群公告
  async setNotice(groupId, content) {
    return mcpRequest("tools/call", {
      name: "qq_set_group_notice",
      arguments: { group_id: groupId, content },
    });
  }

  // 群配置管理
  addGroup(groupId, config = {}) {
    const groups = loadGroups();
    groups[groupId] = {
      ...config,
      addedAt: new Date().toISOString(),
    };
    saveGroups(groups);
  }

  removeGroup(groupId) {
    const groups = loadGroups();
    delete groups[groupId];
    saveGroups(groups);
  }

  getGroupConfig(groupId) {
    const groups = loadGroups();
    return groups[groupId] || null;
  }
}

export default new GroupManager();
