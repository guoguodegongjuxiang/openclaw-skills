// ============================================================
// Hermes MCP 客户端 — 封装 JSON-RPC 2.0 协议通信
// ============================================================
// 支持两种传输：
//   1. HTTP (streamable-http) — 默认
//   2. WebSocket — 可选长连接
// ============================================================

import http from "http";
import https from "https";
import { readFileSync, existsSync } from "fs";
import { resolve } from "path";

const CONFIG_PATH = resolve(process.cwd(), "config/hermes.config.json");

export function loadConfig() {
  if (existsSync(CONFIG_PATH)) {
    return JSON.parse(readFileSync(CONFIG_PATH, "utf-8"));
  }
  return {
    hermesEndpoint: "http://localhost:9100/mcp",
    hermesToken: "",
    bridgePort: 3900,
    timeoutMs: 30000,
    transport: "http",
  };
}

// ── MCP JSON-RPC 2.0 请求 ────────────────────────────────
export function mcpRequest(method, params, id) {
  const config = loadConfig();
  const body = JSON.stringify({
    jsonrpc: "2.0",
    id: id || crypto.randomUUID(),
    method,
    params,
  });

  return new Promise((resolve, reject) => {
    const url = new URL(config.hermesEndpoint);
    const isHttps = url.protocol === "https:";
    const transport = isHttps ? https : http;

    const options = {
      hostname: url.hostname,
      port: url.port || (isHttps ? 443 : 80),
      path: url.pathname,
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json, text/event-stream",
        "Content-Length": Buffer.byteLength(body),
      },
    };

    if (config.hermesToken) {
      options.headers["Authorization"] = `Bearer ${config.hermesToken}`;
    }

    const req = transport.request(options, (res) => {
      let data = "";

      res.on("data", (chunk) => (data += chunk));
      res.on("end", () => {
        try {
          // 处理 SSE 格式响应
          if (res.headers["content-type"]?.includes("text/event-stream")) {
            const events = parseSSE(data);
            const last = events[events.length - 1];
            if (last) {
              const parsed = JSON.parse(last);
              if (parsed.error) reject(new Error(parsed.error.message));
              else resolve(parsed.result);
              return;
            }
          }

          // 普通 JSON 响应
          const parsed = JSON.parse(data);
          if (parsed.error) reject(new Error(parsed.error.message || JSON.stringify(parsed.error)));
          else resolve(parsed.result);
        } catch (e) {
          reject(new Error(`Parse error: ${data.slice(0, 200)}`));
        }
      });
    });

    req.on("error", reject);
    req.write(body);
    req.end();
  });
}

// ── MCP 通知（无 id，不等待响应）─────────────────────────
export function mcpNotify(method, params) {
  const config = loadConfig();
  const body = JSON.stringify({
    jsonrpc: "2.0",
    method,
    params,
  });

  return new Promise((resolve, reject) => {
    const url = new URL(config.hermesEndpoint);
    const isHttps = url.protocol === "https:";
    const transport = isHttps ? https : http;

    const options = {
      hostname: url.hostname,
      port: url.port || (isHttps ? 443 : 80),
      path: url.pathname,
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Content-Length": Buffer.byteLength(body),
      },
    };

    if (config.hermesToken) {
      options.headers["Authorization"] = `Bearer ${config.hermesToken}`;
    }

    const req = transport.request(options, (res) => {
      res.on("data", () => {});
      res.on("end", () => resolve());
    });

    req.on("error", reject);
    req.write(body);
    req.end();
  });
}

// ── SSE 解析 ──────────────────────────────────────────────
function parseSSE(raw) {
  return raw
    .split("\n\n")
    .filter(Boolean)
    .map((block) => {
      const dataLine = block.split("\n").find((l) => l.startsWith("data: "));
      return dataLine ? dataLine.slice(6) : null;
    })
    .filter(Boolean);
}
